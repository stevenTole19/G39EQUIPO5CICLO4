package com.grupo39.almacenesdecadena.almacenes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlmacenesApplicationTests {

	@Test
	void contextLoads() {
	}

}
