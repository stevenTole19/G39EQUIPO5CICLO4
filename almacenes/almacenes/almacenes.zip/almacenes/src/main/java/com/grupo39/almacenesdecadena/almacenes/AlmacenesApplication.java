package com.grupo39.almacenesdecadena.almacenes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlmacenesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlmacenesApplication.class, args);
	}

}
